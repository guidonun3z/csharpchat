﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Threading.Tasks;

namespace chat_winforms_1
{
    public partial class Form1 : Form
    {
        conexion cn = new conexion();
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Thread newThread = new Thread(cn.Start(int.Parse(txt_lis_port.Text)));
            newThread.Start(10);

        }

        private void btn_conectar_Click(object sender, EventArgs e)
        {
            cn.Connect_to(txt_ip.Text, int.Parse(txt_puerto.Text));
            
        }

        private void btn_listener_Click(object sender, EventArgs e)
        {
            cn.Start(int.Parse(txt_lis_port.Text));
        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            string sms_actual= cn.enviar(txt_mensaje.Text) + Environment.NewLine;
            txt_ml_mensajes.Text = txt_ml_mensajes.Text + sms_actual;
        }
    }
}
